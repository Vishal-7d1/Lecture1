
#include <iostream>
using namespace std;
int main() {
    int a,b,sum;
    cin>>a>>b;
    sum=a+b;

    cout << "sum :"<<sum;

    return 0;
}
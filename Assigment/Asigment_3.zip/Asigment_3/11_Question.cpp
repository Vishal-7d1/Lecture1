#include <iostream>
using namespace std;
int main() {
  for(int i=2;i<=100;i+=2)
  {
    cout<<i<<" ";
  }
  return 0;
}

#include<iostream>
using namespace std;

int main(){
    int A,B;
    cin>>A>>B;
    if(A>B){
        cout<<"Print A is grater "<<endl;
    }
    else{
        cout<<"Print B is grater"<<endl;
    }
    return 0;
}
#include<iostream>
using namespace std;

int main(){
    int p,r,t;
    cin>>p>>r>>t;
    int SI=(p*r*t)/100;
    cout<<"Simple Intrest : "<<SI;


    return 0;
}
